/**
 * Lightweight Web Audio API synthesizer for SaaS UI feedback
 * Pure client-side with zero external assets required
 */
export function playChimeSound(volume: number = 80) {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;

    const ctx = new AudioContextClass();
    const now = ctx.currentTime;
    const gainNode = ctx.createGain();
    const normalizedVol = Math.max(0.01, Math.min(1, volume / 100)) * 0.25;

    gainNode.gain.setValueAtTime(0.001, now);
    gainNode.gain.exponentialRampToValueAtTime(normalizedVol, now + 0.04);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.65);
    gainNode.connect(ctx.destination);

    // Primary chime tone (harmonic 587.33Hz D5 -> 880Hz A5)
    const osc1 = ctx.createOscillator();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now);
    osc1.frequency.exponentialRampToValueAtTime(880, now + 0.12);
    osc1.connect(gainNode);
    osc1.start(now);
    osc1.stop(now + 0.7);

    // Secondary subtle sparkle harmonic
    const osc2 = ctx.createOscillator();
    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(1174.66, now + 0.06);
    osc2.connect(gainNode);
    osc2.start(now + 0.06);
    osc2.stop(now + 0.6);
  } catch (err) {
    // Graceful fallback if user hasn't interacted or audio is blocked
    console.debug('Audio chime playback omitted:', err);
  }
}

export function playTickSound() {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;

    const ctx = new AudioContextClass();
    const now = ctx.currentTime;
    const gainNode = ctx.createGain();

    gainNode.gain.setValueAtTime(0.05, now);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.05);
    gainNode.connect(ctx.destination);

    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1200, now);
    osc.connect(gainNode);
    osc.start(now);
    osc.stop(now + 0.05);
  } catch {
    // Silent
  }
}
