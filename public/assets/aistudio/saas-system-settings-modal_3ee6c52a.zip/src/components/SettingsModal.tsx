import React, { useState, useEffect, useCallback } from 'react';
import {
  Cpu,
  Palette,
  ShieldCheck,
  X,
  RotateCcw,
  Save,
  CheckCircle,
  Menu,
  Sliders,
  Settings as SettingsIcon,
  ChevronRight,
} from 'lucide-react';
import { TabType, SystemSettingsState } from '../types/settings';
import { DevicesNetworkTab } from './tabs/DevicesNetworkTab';
import { ProfileThemeTab } from './tabs/ProfileThemeTab';
import { AccountSecurityTab } from './tabs/AccountSecurityTab';
import { playChimeSound, playTickSound } from '../utils/sound';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: TabType;
}

const DEFAULT_SETTINGS: SystemSettingsState = {
  // Tab 1: Devices & Network
  deviceName: 'MacBook Pro M3 Max - Studio Node',
  hardwareType: 'laptop',
  relayAutoFailover: true,
  selectedRelayServer: 'tokyo',
  autoAccept: true,
  soundEnabled: true,
  soundVolume: 80,
  transferBandwidthLimit: 'Không giới hạn (Gigabit)',

  // Tab 2: Profile & Theme
  displayName: 'Alex Rivera',
  username: '@alex.dev',
  bio: 'Systems Architect & Distributed Network Core. Building resilient mesh relays and high-throughput real-time protocols.',
  roleTag: 'Principal Architect · Tokyo Hub',
  avatarUrl: '/src/assets/images/user_avatar_pro_1792761982616.jpg',
  bannerUrl: '/src/assets/images/profile_banner_mesh_1792761982850.jpg',
  activeTheme: 'amethyst',
  badges: ['early_adopter', 'relay_master', 'verified_dev', 'security_shield'],

  // Tab 3: Account & Security
  email: 'alex.rivera@datacore.io',
  emailVerified: true,
  twoFactorEnabled: true,
};

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'devices',
}) => {
  const [activeTab, setActiveTab] = useState<TabType>(initialTab);
  const [settings, setSettings] = useState<SystemSettingsState>(DEFAULT_SETTINGS);
  const [savedSettings, setSavedSettings] = useState<SystemSettingsState>(DEFAULT_SETTINGS);
  const [hasChanges, setHasChanges] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  // Sync initial tab when changed from props
  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  // Check if current settings differ from saved
  useEffect(() => {
    const isDifferent = JSON.stringify(settings) !== JSON.stringify(savedSettings);
    setHasChanges(isDifferent);
  }, [settings, savedSettings]);

  // Keyboard shortcut: ESC to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const triggerToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3200);
  }, []);

  const updateSetting = useCallback(
    <K extends keyof SystemSettingsState>(key: K, value: SystemSettingsState[K]) => {
      setSettings((prev) => ({
        ...prev,
        [key]: value,
      }));
    },
    []
  );

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      setSavedSettings(settings);
      setIsSaving(false);
      setHasChanges(false);
      if (settings.soundEnabled) {
        playChimeSound(settings.soundVolume);
      }
      triggerToast('Đã lưu tất cả thay đổi cài đặt hệ thống thành công');
    }, 450);
  };

  const handleReset = () => {
    playTickSound();
    setSettings(savedSettings);
    setHasChanges(false);
    triggerToast('Đã khôi phục các cài đặt về trạng thái đã lưu gần nhất');
  };

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Cài đặt hệ thống"
      className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 md:p-6 lg:p-8 bg-slate-950/80 backdrop-blur-md overflow-hidden animate-in fade-in duration-200"
    >
      {/* Modal Container */}
      <div className="relative w-full h-full sm:h-auto sm:max-h-[92vh] sm:max-w-5xl bg-slate-950 rounded-none sm:rounded-2xl border-0 sm:border border-slate-800 shadow-2xl flex flex-col md:flex-row overflow-hidden">
        {/* MOBILE TOP BAR (visible on screens < md) */}
        <div className="md:hidden flex items-center justify-between p-4 bg-slate-950 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-300 hover:text-white bg-slate-900 rounded-lg border border-slate-800"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <SettingsIcon className="w-4 h-4 text-emerald-400" />
              <span className="font-bold text-white text-sm">Cài đặt hệ thống</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-900 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* LEFT SIDEBAR (w-64 bg-slate-950 border-r border-slate-800 p-4 flex flex-col justify-between) */}
        <aside
          className={`w-full md:w-64 bg-slate-950 border-r border-slate-800 p-4 flex flex-col justify-between shrink-0 transition-all ${
            mobileMenuOpen ? 'block' : 'hidden md:flex'
          }`}
        >
          {/* Top Section */}
          <div className="space-y-6">
            {/* Sidebar Title */}
            <div className="hidden md:flex items-center justify-between px-2 pt-1">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-sm">
                  <Sliders className="w-4 h-4" />
                </div>
                <div>
                  <h1 className="text-sm font-bold text-white tracking-tight">Cài đặt hệ thống</h1>
                  <p className="text-[10px] text-slate-400 font-mono">v2.4.0 · Linear SaaS</p>
                </div>
              </div>
            </div>

            {/* Navigation Tabs */}
            <nav className="space-y-1.5" aria-label="Tabs cài đặt">
              {/* Tab 1: Devices & Network */}
              <button
                type="button"
                onClick={() => {
                  playTickSound();
                  setActiveTab('devices');
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold border transition-all ${
                  activeTab === 'devices'
                    ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30 shadow-[0_0_12px_rgba(16,185,129,0.12)]'
                    : 'text-slate-400 border-transparent hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Cpu className={`w-4 h-4 ${activeTab === 'devices' ? 'text-emerald-400' : 'text-slate-500'}`} />
                  <span className="whitespace-nowrap">Devices & Network</span>
                </div>
                {activeTab === 'devices' && <ChevronRight className="w-3.5 h-3.5 text-emerald-400" />}
              </button>

              {/* Tab 2: Profile & Theme */}
              <button
                type="button"
                onClick={() => {
                  playTickSound();
                  setActiveTab('profile');
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold border transition-all ${
                  activeTab === 'profile'
                    ? 'text-purple-400 bg-purple-500/10 border-purple-500/30 shadow-[0_0_12px_rgba(168,85,247,0.12)]'
                    : 'text-slate-400 border-transparent hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Palette className={`w-4 h-4 ${activeTab === 'profile' ? 'text-purple-400' : 'text-slate-500'}`} />
                  <span className="whitespace-nowrap">Profile & Theme</span>
                </div>
                {activeTab === 'profile' && <ChevronRight className="w-3.5 h-3.5 text-purple-400" />}
              </button>

              {/* Tab 3: Account & Security */}
              <button
                type="button"
                onClick={() => {
                  playTickSound();
                  setActiveTab('security');
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold border transition-all ${
                  activeTab === 'security'
                    ? 'text-teal-400 bg-teal-500/10 border-teal-500/30 shadow-[0_0_12px_rgba(20,184,166,0.12)]'
                    : 'text-slate-400 border-transparent hover:text-slate-200 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <ShieldCheck
                    className={`w-4 h-4 ${activeTab === 'security' ? 'text-teal-400' : 'text-slate-500'}`}
                  />
                  <span className="whitespace-nowrap">Account & Security</span>
                </div>
                {activeTab === 'security' && <ChevronRight className="w-3.5 h-3.5 text-teal-400" />}
              </button>
            </nav>
          </div>

          {/* Bottom Sidebar: User Pill & Keyboard hint */}
          <div className="pt-4 border-t border-slate-800/80 space-y-3">
            <div className="flex items-center gap-2.5 p-2 rounded-xl bg-slate-900/70 border border-slate-800/60">
              <div className="relative w-8 h-8 rounded-full overflow-hidden shrink-0 ring-1 ring-slate-700">
                <img
                  src={settings.avatarUrl}
                  alt={settings.displayName}
                  className="w-full h-full object-cover"
                />
                <span className="absolute bottom-0 right-0 w-2 h-2 rounded-full bg-emerald-500 border border-slate-950" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-xs font-semibold text-white truncate">{settings.displayName}</div>
                <div className="text-[10px] text-slate-400 truncate">{settings.username}</div>
              </div>
            </div>

            <div className="hidden md:flex items-center justify-between text-[11px] text-slate-500 px-1 font-mono">
              <span>Đóng cửa sổ</span>
              <kbd className="px-1.5 py-0.5 rounded bg-slate-900 border border-slate-700/80 text-[10px] text-slate-300">
                ESC
              </kbd>
            </div>
          </div>
        </aside>

        {/* RIGHT CONTENT FRAME (flex-1 bg-slate-900 p-6 overflow-y-auto space-y-6 text-slate-100) */}
        <main className="flex-1 bg-slate-900 p-4 sm:p-6 md:p-8 overflow-y-auto space-y-6 text-slate-100 flex flex-col justify-between relative">
          <div>
            {/* Top Close bar inside main area */}
            <div className="hidden md:flex items-center justify-between pb-4 border-b border-slate-800/80">
              <div className="text-xs text-slate-400 flex items-center gap-2">
                <span>Cài đặt hệ thống</span>
                <span>/</span>
                <span className="text-white font-medium capitalize">
                  {activeTab === 'devices'
                    ? 'Devices & Network'
                    : activeTab === 'profile'
                    ? 'Profile & Theme'
                    : 'Account & Security'}
                </span>
              </div>

              {/* Close Button with ESC bubble */}
              <button
                onClick={onClose}
                title="Đóng cài đặt (ESC)"
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-700/60 transition-colors"
              >
                <span className="text-[11px] font-mono">ESC</span>
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Tab Contents */}
            <div className="pt-2 sm:pt-4">
              {activeTab === 'devices' && (
                <DevicesNetworkTab
                  settings={settings}
                  updateSetting={updateSetting}
                  triggerToast={triggerToast}
                />
              )}

              {activeTab === 'profile' && (
                <ProfileThemeTab
                  settings={settings}
                  updateSetting={updateSetting}
                  triggerToast={triggerToast}
                />
              )}

              {activeTab === 'security' && (
                <AccountSecurityTab
                  settings={settings}
                  updateSetting={updateSetting}
                  triggerToast={triggerToast}
                />
              )}
            </div>
          </div>

          {/* DISCORD / LINEAR STYLE FLOATING UNSAVED CHANGES BAR */}
          {hasChanges && (
            <div className="sticky bottom-0 left-0 right-0 -mx-4 -mb-4 sm:-mx-6 sm:-mb-6 md:-mx-8 md:-mb-8 p-3 sm:p-4 bg-slate-950/95 backdrop-blur-xl border-t border-slate-800 flex items-center justify-between gap-3 shadow-[0_-8px_25px_rgba(0,0,0,0.5)] z-20 animate-in slide-in-from-bottom duration-200">
              <div className="flex items-center gap-2 min-w-0">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse shrink-0" />
                <span className="text-xs font-semibold text-slate-200 truncate">
                  Cẩn thận — Bạn có những thay đổi chưa được lưu!
                </span>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleReset}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-700 transition-colors flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Đặt lại</span>
                </button>
                <button
                  type="button"
                  onClick={handleSave}
                  disabled={isSaving}
                  className="px-4 py-1.5 rounded-lg text-xs font-semibold text-slate-950 bg-emerald-500 hover:bg-emerald-400 shadow-md transition-colors flex items-center gap-1.5"
                >
                  <Save className={`w-3.5 h-3.5 ${isSaving ? 'animate-spin' : ''}`} />
                  <span>{isSaving ? 'Đang lưu...' : 'Lưu thay đổi'}</span>
                </button>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900/95 border border-slate-700 text-white text-xs font-medium shadow-2xl backdrop-blur-md animate-in slide-in-from-bottom-2 duration-200">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
};
