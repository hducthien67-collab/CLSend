import React, { useState } from 'react';
import {
  Laptop,
  Monitor,
  Smartphone,
  Tv,
  Radio,
  Volume2,
  VolumeX,
  Volume1,
  Copy,
  Check,
  RefreshCw,
  Zap,
  Globe2,
  Lock,
  Sparkles,
} from 'lucide-react';
import { HardwareType, RelayServer, SystemSettingsState } from '../../types/settings';
import { playChimeSound } from '../../utils/sound';

interface Props {
  settings: SystemSettingsState;
  updateSetting: <K extends keyof SystemSettingsState>(key: K, value: SystemSettingsState[K]) => void;
  triggerToast: (msg: string) => void;
}

const HARDWARE_OPTIONS: Array<{
  id: HardwareType;
  label: string;
  sub: string;
  icon: React.ComponentType<{ className?: string }>;
  spec: string;
}> = [
  {
    id: 'laptop',
    label: 'Laptop',
    sub: 'Máy tính xách tay',
    icon: Laptop,
    spec: 'Pin & Di động',
  },
  {
    id: 'pc',
    label: 'Máy trạm PC',
    sub: 'Desktop Workstation',
    icon: Monitor,
    spec: 'Hiệu năng cao',
  },
  {
    id: 'phone',
    label: 'Điện thoại',
    sub: 'Mobile Phone',
    icon: Smartphone,
    spec: 'iOS / Android',
  },
  {
    id: 'tv',
    label: 'Smart TV',
    sub: 'Display & Meeting',
    icon: Tv,
    spec: 'Màn hình lớn',
  },
];

const RELAY_SERVERS: RelayServer[] = [
  { id: 'tokyo', name: 'Tokyo Node #01', region: 'Asia-East (NRT)', flag: '🇯🇵', ping: 24, status: 'online' },
  { id: 'singapore', name: 'Singapore Gateway #02', region: 'Asia-SE (SIN)', flag: '🇸🇬', ping: 38, status: 'online' },
  { id: 'frankfurt', name: 'Frankfurt Core #03', region: 'EU-Central (FRA)', flag: '🇩🇪', ping: 145, status: 'online' },
  { id: 'sanjose', name: 'San Jose Silicon #04', region: 'US-West (SJC)', flag: '🇺🇸', ping: 162, status: 'online' },
];

export const DevicesNetworkTab: React.FC<Props> = ({ settings, updateSetting, triggerToast }) => {
  const [copiedId, setCopiedId] = useState(false);
  const [isTestingPing, setIsTestingPing] = useState(false);
  const [activeRelayList, setActiveRelayList] = useState<RelayServer[]>(RELAY_SERVERS);
  const [isChimePlaying, setIsChimePlaying] = useState(false);

  const deviceUUID = 'node_8f2a-9e1c-b74d-77e2';

  const handleCopyDeviceId = () => {
    navigator.clipboard.writeText(deviceUUID);
    setCopiedId(true);
    triggerToast('Đã sao chép Node ID vào clipboard');
    setTimeout(() => setCopiedId(false), 2000);
  };

  const handleTestPing = () => {
    setIsTestingPing(true);
    setTimeout(() => {
      setActiveRelayList((prev) =>
        prev.map((s) => ({
          ...s,
          ping: Math.floor(Math.random() * 20) + (s.id === 'tokyo' ? 18 : s.id === 'singapore' ? 32 : 140),
        }))
      );
      setIsTestingPing(false);
      triggerToast('Đã cập nhật chỉ số Ping máy chủ Relay trực tuyến');
    }, 850);
  };

  const handleTestChime = () => {
    if (!settings.soundEnabled) {
      triggerToast('Vui lòng bật Âm thanh thông báo trước khi nghe thử');
      return;
    }
    setIsChimePlaying(true);
    playChimeSound(settings.soundVolume);
    setTimeout(() => setIsChimePlaying(false), 700);
    triggerToast('Đang phát âm thanh thông báo chuẩn');
  };

  const selectedServer = activeRelayList.find((s) => s.id === settings.selectedRelayServer) || activeRelayList[0];

  return (
    <div className="space-y-8 max-w-3xl">
      {/* Section Header */}
      <div className="border-b border-slate-800 pb-5">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-400">
          <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
          Thiết bị & Cấu hình mạng
        </div>
        <h2 className="text-xl font-bold text-white mt-1">Devices & Network Architecture</h2>
        <p className="text-sm text-slate-400 mt-1">
          Quản lý định danh nút thiết bị, phân loại phần cứng và định tuyến qua máy chủ Relay trực tuyến 24/7.
        </p>
      </div>

      {/* 1. Device Display Name & Node ID */}
      <div className="bg-slate-950/60 rounded-xl border border-slate-800/80 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <label className="text-sm font-semibold text-slate-200 block">Tên thiết bị hiển thị</label>
            <p className="text-xs text-slate-400">Tên định danh hiển thị với các thành viên khác khi truyền dữ liệu qua mạng p2p.</p>
          </div>
          <span className="text-[11px] font-mono px-2.5 py-1 rounded-md bg-emerald-950/60 text-emerald-400 border border-emerald-800/40 w-fit">
            Nút cục bộ chính
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="sm:col-span-2">
            <input
              type="text"
              value={settings.deviceName}
              onChange={(e) => updateSetting('deviceName', e.target.value)}
              placeholder="Nhập tên thiết bị..."
              className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700/80 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/50 transition-colors"
            />
          </div>
          <div className="flex items-center gap-2">
            <div className="flex-1 px-3 py-2 bg-slate-900/90 border border-slate-800 rounded-lg text-xs font-mono text-slate-300 truncate">
              {deviceUUID}
            </div>
            <button
              onClick={handleCopyDeviceId}
              title="Sao chép Device UUID"
              className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 transition-colors shrink-0"
            >
              {copiedId ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* 2. Hardware Type Selection */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-200">Loại phần cứng thiết bị</h3>
            <p className="text-xs text-slate-400">Chọn cấu hình phần cứng phù hợp để tối ưu hoá băng thông và gói tin.</p>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {HARDWARE_OPTIONS.find((h) => h.id === settings.hardwareType)?.label}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {HARDWARE_OPTIONS.map((item) => {
            const Icon = item.icon;
            const isSelected = settings.hardwareType === item.id;
            return (
              <button
                key={item.id}
                onClick={() => updateSetting('hardwareType', item.id)}
                type="button"
                className={`flex flex-col text-left p-3.5 rounded-xl border transition-all relative ${
                  isSelected
                    ? 'bg-emerald-950/20 border-emerald-500/80 shadow-[0_0_15px_rgba(16,185,129,0.12)] ring-1 ring-emerald-500/40'
                    : 'bg-slate-950/40 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div
                    className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                      isSelected ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  {isSelected && (
                    <div className="w-4 h-4 rounded-full bg-emerald-500 flex items-center justify-center text-slate-950">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </div>
                  )}
                </div>
                <div className="font-semibold text-sm text-slate-100">{item.label}</div>
                <div className="text-[11px] text-slate-400 mt-0.5">{item.sub}</div>
                <div className="text-[10px] text-slate-500 font-mono mt-2 pt-2 border-t border-slate-800/80">
                  {item.spec}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. 24/7 Relay Server Infrastructure */}
      <div className="bg-slate-950/70 rounded-xl border border-slate-800 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Radio className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-semibold text-white">Máy chủ Relay trực tuyến 24/7</h3>
                <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  Uptime 99.98%
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Đảm bảo đường truyền xuyên NAT, tường lửa và kết nối p2p liên tục với độ trễ thấp.
              </p>
            </div>
          </div>

          <button
            onClick={handleTestPing}
            disabled={isTestingPing}
            type="button"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 transition-colors disabled:opacity-50 self-start sm:self-auto"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isTestingPing ? 'animate-spin text-emerald-400' : ''}`} />
            <span>{isTestingPing ? 'Đang đo ping...' : 'Kiểm tra Ping'}</span>
          </button>
        </div>

        {/* Selected Server Info Card */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="p-3 bg-slate-900/80 rounded-lg border border-slate-800/80">
            <div className="text-[11px] text-slate-400">Nút Relay Hiện Tại</div>
            <div className="text-sm font-semibold text-white mt-1 flex items-center gap-1.5">
              <span>{selectedServer.flag}</span>
              <span>{selectedServer.name}</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">{selectedServer.region}</div>
          </div>

          <div className="p-3 bg-slate-900/80 rounded-lg border border-slate-800/80">
            <div className="text-[11px] text-slate-400">Độ trễ Latency</div>
            <div className="text-sm font-bold text-emerald-400 font-mono mt-1 tabular-nums flex items-center gap-1">
              <Zap className="w-3.5 h-3.5" />
              <span>{selectedServer.ping} ms</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">Đường truyền siêu tốc</div>
          </div>

          <div className="p-3 bg-slate-900/80 rounded-lg border border-slate-800/80">
            <div className="text-[11px] text-slate-400">Bảo mật giao thức</div>
            <div className="text-sm font-semibold text-slate-200 mt-1 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-emerald-400" />
              <span>TLS 1.3 · Port 443</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5">Mã hóa đầu cuối P2P</div>
          </div>
        </div>

        {/* Relay Server Grid Selector */}
        <div className="space-y-2 pt-1">
          <label className="text-xs font-semibold text-slate-300 block">Chọn cụm máy chủ ưu tiên</label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {activeRelayList.map((srv) => (
              <button
                key={srv.id}
                type="button"
                onClick={() => updateSetting('selectedRelayServer', srv.id)}
                className={`flex items-center justify-between p-3 rounded-lg border text-left transition-all ${
                  settings.selectedRelayServer === srv.id
                    ? 'bg-emerald-950/30 border-emerald-500/50 text-white'
                    : 'bg-slate-900/50 border-slate-800 text-slate-300 hover:bg-slate-900 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <span className="text-base">{srv.flag}</span>
                  <div className="truncate">
                    <div className="text-xs font-medium text-slate-200 truncate">{srv.name}</div>
                    <div className="text-[10px] text-slate-400">{srv.region}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-xs font-mono text-emerald-400 font-semibold tabular-nums">
                    {srv.ping} ms
                  </span>
                  <div
                    className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                      settings.selectedRelayServer === srv.id
                        ? 'border-emerald-500 bg-emerald-500'
                        : 'border-slate-700'
                    }`}
                  >
                    {settings.selectedRelayServer === srv.id && (
                      <div className="w-1.5 h-1.5 rounded-full bg-slate-950"></div>
                    )}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Failover Relay Toggle */}
        <div className="flex items-center justify-between pt-2">
          <div>
            <div className="text-xs font-medium text-slate-200">Tự động chuyển đổi máy chủ dự phòng (Failover)</div>
            <div className="text-[11px] text-slate-400">Tự động chọn node có ping thấp nhất khi kết nối bị chập chờn.</div>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={settings.relayAutoFailover}
            onClick={() => updateSetting('relayAutoFailover', !settings.relayAutoFailover)}
            className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
              settings.relayAutoFailover ? 'bg-emerald-600' : 'bg-slate-800'
            }`}
          >
            <div
              className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                settings.relayAutoFailover ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>

      {/* 4. Auto-Accept & Notifications Settings */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Auto Accept Switch Card */}
        <div className="bg-slate-950/60 rounded-xl border border-slate-800 p-5 flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase text-emerald-400 tracking-wider">Truyền tải mạng</span>
              <Sparkles className="w-4 h-4 text-emerald-400" />
            </div>
            <h3 className="text-sm font-semibold text-white mt-1">Tự động chấp nhận (Auto-Accept)</h3>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Tự động chấp nhận yêu cầu kết nối và chuyển nhận tệp tin từ các thiết bị đã xác thực trong nhóm mà không cần nhắc xác nhận thủ công.
            </p>
          </div>

          <div className="flex items-center justify-between pt-3 border-t border-slate-800/80">
            <span className="text-xs font-medium text-slate-300">
              {settings.autoAccept ? 'Đang bật Auto-Accept' : 'Đã tắt tính năng'}
            </span>
            <button
              type="button"
              role="switch"
              aria-checked={settings.autoAccept}
              onClick={() => updateSetting('autoAccept', !settings.autoAccept)}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                settings.autoAccept ? 'bg-emerald-600' : 'bg-slate-800'
              }`}
            >
              <div
                className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                  settings.autoAccept ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>

        {/* Sound Effects & Volume Card */}
        <div className="bg-slate-950/60 rounded-xl border border-slate-800 p-5 flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase text-emerald-400 tracking-wider">Phản hồi âm thanh</span>
              {settings.soundEnabled ? (
                <Volume2 className="w-4 h-4 text-emerald-400" />
              ) : (
                <VolumeX className="w-4 h-4 text-slate-500" />
              )}
            </div>
            <h3 className="text-sm font-semibold text-white mt-1">Hiệu ứng âm thanh thông báo</h3>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Phát chuông thông báo âm sắc cao cấp khi có thiết bị kết nối mới hoặc khi quá trình truyền tệp hoàn tất.
            </p>
          </div>

          <div className="space-y-3 pt-3 border-t border-slate-800/80">
            {/* Toggle */}
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-300">Bật âm thanh</span>
              <button
                type="button"
                role="switch"
                aria-checked={settings.soundEnabled}
                onClick={() => updateSetting('soundEnabled', !settings.soundEnabled)}
                className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                  settings.soundEnabled ? 'bg-emerald-600' : 'bg-slate-800'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    settings.soundEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Volume Slider & Test Button */}
            {settings.soundEnabled && (
              <div className="space-y-2 pt-1">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>Âm lượng</span>
                  <span className="font-mono text-emerald-400 font-semibold">{settings.soundVolume}%</span>
                </div>
                <div className="flex items-center gap-3">
                  <Volume1 className="w-4 h-4 text-slate-500 shrink-0" />
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={settings.soundVolume}
                    onChange={(e) => updateSetting('soundVolume', Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                  />
                  <Volume2 className="w-4 h-4 text-slate-400 shrink-0" />
                </div>
              </div>
            )}

            <button
              onClick={handleTestChime}
              type="button"
              className={`w-full mt-2 py-2 px-3 rounded-lg text-xs font-medium border flex items-center justify-center gap-2 transition-all ${
                isChimePlaying
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-[0_0_12px_rgba(16,185,129,0.2)]'
                  : 'bg-slate-900 hover:bg-slate-800 text-slate-200 border-slate-700/80'
              }`}
            >
              <Volume2 className={`w-3.5 h-3.5 ${isChimePlaying ? 'animate-bounce text-emerald-400' : ''}`} />
              <span>{isChimePlaying ? 'Đang phát tiếng chuông...' : 'Nghe thử âm thanh (Test Chime)'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
