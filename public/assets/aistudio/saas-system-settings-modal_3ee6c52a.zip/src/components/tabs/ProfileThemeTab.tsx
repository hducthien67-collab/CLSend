import React, { useState } from 'react';
import {
  Palette,
  Sparkles,
  Shield,
  Award,
  Flame,
  Zap,
  Code2,
  Check,
  Upload,
  RefreshCw,
  Sliders,
  Cpu,
  Globe,
  Radio,
} from 'lucide-react';
import { BadgeItem, SystemSettingsState, ThemePreset } from '../../types/settings';

interface Props {
  settings: SystemSettingsState;
  updateSetting: <K extends keyof SystemSettingsState>(key: K, value: SystemSettingsState[K]) => void;
  triggerToast: (msg: string) => void;
}

const THEME_PRESETS: ThemePreset[] = [
  {
    id: 'amethyst',
    name: 'Cyber Amethyst',
    primary: '#A855F7',
    accent: '#C084FC',
    previewGradient: 'from-purple-900/60 via-slate-900 to-indigo-950/70',
    borderClass: 'border-purple-500/50',
  },
  {
    id: 'emerald',
    name: 'Emerald Matrix',
    primary: '#10B981',
    accent: '#34D399',
    previewGradient: 'from-emerald-950/70 via-slate-900 to-teal-950/60',
    borderClass: 'border-emerald-500/50',
  },
  {
    id: 'teal',
    name: 'Linear Teal',
    primary: '#14B8A6',
    accent: '#2DD4BF',
    previewGradient: 'from-teal-950/70 via-slate-900 to-cyan-950/60',
    borderClass: 'border-teal-500/50',
  },
  {
    id: 'slate',
    name: 'Linear Obsidian',
    primary: '#64748B',
    accent: '#94A3B8',
    previewGradient: 'from-slate-800/80 via-slate-900 to-slate-950',
    borderClass: 'border-slate-500/50',
  },
  {
    id: 'monochrome',
    name: 'Vercel Noir',
    primary: '#FFFFFF',
    accent: '#E2E8F0',
    previewGradient: 'from-zinc-900 via-neutral-950 to-black',
    borderClass: 'border-zinc-400/50',
  },
  {
    id: 'oceanic',
    name: 'Deep Oceanic',
    primary: '#0EA5E9',
    accent: '#38BDF8',
    previewGradient: 'from-sky-950/80 via-slate-900 to-blue-950/70',
    borderClass: 'border-sky-500/50',
  },
];

const AVAILABLE_BADGES: BadgeItem[] = [
  {
    id: 'early_adopter',
    name: 'Early Adopter',
    icon: 'Flame',
    description: 'Thành viên tham gia từ đợt phát hành Alpha v0.1',
    active: true,
  },
  {
    id: 'relay_master',
    name: 'Relay Master',
    icon: 'Radio',
    description: 'Đã vận hành cụm Relay Node trên 1000 giờ',
    active: true,
  },
  {
    id: 'verified_dev',
    name: 'Verified Engineer',
    icon: 'Code2',
    description: 'Tài khoản lập trình viên lõi xác thực',
    active: true,
  },
  {
    id: 'security_shield',
    name: 'Security Guard',
    icon: 'Shield',
    description: 'Đã kích hoạt xác thực hai lớp và bảo mật 6 số',
    active: true,
  },
  {
    id: 'speed_pro',
    name: 'Low Latency Pioneer',
    icon: 'Zap',
    description: 'Tối ưu hoá đường truyền < 20ms liên tục',
    active: false,
  },
];

const AVATAR_OPTIONS = [
  {
    id: 'cyber_hero',
    url: '/src/assets/images/user_avatar_pro_1792761982616.jpg',
    label: 'Cyber Architect',
  },
  {
    id: 'avatar_svg_1',
    url: 'https://api.dicebear.com/7.x/bottts-neutral/svg?seed=AlexNode',
    label: 'Bot Matrix',
  },
  {
    id: 'avatar_svg_2',
    url: 'https://api.dicebear.com/7.x/identicon/svg?seed=LinearSaaS',
    label: 'Geometric Mesh',
  },
];

export const ProfileThemeTab: React.FC<Props> = ({ settings, updateSetting, triggerToast }) => {
  const [bioCharLimit] = useState(190);
  const [activeBannerIdx, setActiveBannerIdx] = useState(0);

  const BANNER_PRESETS = [
    {
      id: 'generated_banner',
      name: 'Topography Neon',
      url: '/src/assets/images/profile_banner_mesh_1792761982850.jpg',
    },
    {
      id: 'cyber_mesh',
      name: 'Dark Nebula',
      url: 'linear-gradient(135deg, #1e1b4b 0%, #0f172a 50%, #312e81 100%)',
    },
    {
      id: 'linear_glow',
      name: 'Linear Aurora',
      url: 'linear-gradient(135deg, #064e3b 0%, #022c22 40%, #0f172a 100%)',
    },
  ];

  const currentTheme = THEME_PRESETS.find((t) => t.id === settings.activeTheme) || THEME_PRESETS[0];

  const toggleBadge = (badgeId: string) => {
    const exists = settings.badges.includes(badgeId);
    let nextBadges: string[];
    if (exists) {
      nextBadges = settings.badges.filter((id) => id !== badgeId);
      triggerToast('Đã ẩn huy hiệu khỏi hồ sơ');
    } else {
      nextBadges = [...settings.badges, badgeId];
      triggerToast('Đã kích hoạt hiển thị huy hiệu trên thẻ hồ sơ');
    }
    updateSetting('badges', nextBadges);
  };

  const getBadgeIcon = (iconName: string) => {
    switch (iconName) {
      case 'Flame':
        return <Flame className="w-3.5 h-3.5 text-amber-400" />;
      case 'Radio':
        return <Radio className="w-3.5 h-3.5 text-emerald-400" />;
      case 'Code2':
        return <Code2 className="w-3.5 h-3.5 text-cyan-400" />;
      case 'Shield':
        return <Shield className="w-3.5 h-3.5 text-purple-400" />;
      case 'Zap':
        return <Zap className="w-3.5 h-3.5 text-yellow-400" />;
      default:
        return <Award className="w-3.5 h-3.5 text-purple-400" />;
    }
  };

  return (
    <div className="space-y-8 max-w-3xl">
      {/* Section Header */}
      <div className="border-b border-slate-800 pb-5">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-purple-400">
          <span className="w-2 h-2 rounded-full bg-purple-500"></span>
          Tuỳ chỉnh hồ sơ & Giao diện
        </div>
        <h2 className="text-xl font-bold text-white mt-1">Profile & Theme Customization</h2>
        <p className="text-sm text-slate-400 mt-1">
          Thiết kế thẻ danh thiếp phong cách Discord Popout, bảng màu chủ đạo SaaS và huy hiệu danh dự.
        </p>
      </div>

      {/* 1. DISCORD-STYLE PROFILE CARD PREVIEW */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-200">Xem trước thẻ hồ sơ (Discord Popout Preview)</h3>
            <p className="text-xs text-slate-400">Cách thẻ hồ sơ của bạn hiển thị với bạn bè và đồng nghiệp trên mạng lưới.</p>
          </div>
          <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-purple-950/60 text-purple-300 border border-purple-800/40">
            Realtime Preview
          </span>
        </div>

        {/* Discord Card Frame */}
        <div className="w-full max-w-md mx-auto sm:mx-0 bg-slate-950 rounded-2xl border border-slate-800 shadow-2xl overflow-hidden relative group">
          {/* Cover Banner */}
          <div
            className="h-32 w-full relative bg-slate-900 overflow-hidden"
            style={
              BANNER_PRESETS[activeBannerIdx].url.startsWith('http') || BANNER_PRESETS[activeBannerIdx].url.startsWith('/')
                ? {
                    backgroundImage: `url('${BANNER_PRESETS[activeBannerIdx].url}')`,
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                  }
                : {
                    background: BANNER_PRESETS[activeBannerIdx].url,
                  }
            }
          >
            {/* Scrim Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-transparent" />
            <div className="absolute top-3 right-3 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-950/80 backdrop-blur-md text-[11px] font-medium text-slate-300 border border-slate-800">
              <span
                className="w-2 h-2 rounded-full animate-pulse"
                style={{ backgroundColor: currentTheme.primary }}
              />
              <span>{currentTheme.name}</span>
            </div>
          </div>

          {/* Profile Header Block */}
          <div className="px-5 pb-5 pt-0 relative -mt-12 space-y-4">
            {/* Avatar & Badges row */}
            <div className="flex items-end justify-between">
              <div className="relative">
                <div className="w-22 h-22 rounded-full p-1 bg-slate-950 ring-2 ring-slate-800 relative overflow-hidden shadow-xl">
                  <img
                    src={settings.avatarUrl}
                    alt={settings.displayName}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover rounded-full bg-slate-800"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src =
                        'https://api.dicebear.com/7.x/bottts-neutral/svg?seed=Alex';
                    }}
                  />
                </div>
                {/* Online indicator */}
                <span className="absolute bottom-1 right-1 w-5 h-5 rounded-full bg-emerald-500 border-4 border-slate-950" title="Trực tuyến" />
              </div>

              {/* Badges Cluster */}
              <div className="flex items-center gap-1 bg-slate-900/90 border border-slate-800/80 p-1.5 rounded-lg mb-2 shadow-sm">
                {AVAILABLE_BADGES.filter((b) => settings.badges.includes(b.id)).map((badge) => (
                  <div
                    key={badge.id}
                    title={`${badge.name}: ${badge.description}`}
                    className="p-1.5 rounded-md bg-slate-800/80 hover:bg-slate-700 transition-colors cursor-pointer"
                  >
                    {getBadgeIcon(badge.icon)}
                  </div>
                ))}
              </div>
            </div>

            {/* User identity & Role */}
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h4 className="text-lg font-bold text-white tracking-tight">{settings.displayName}</h4>
                <span className="text-xs text-slate-400 font-mono">{settings.username}</span>
              </div>
              <div className="text-xs font-medium text-purple-400 flex items-center gap-1.5">
                <span>{settings.roleTag}</span>
                <span className="text-slate-600">·</span>
                <span className="text-slate-400">Node #01 Tokyo</span>
              </div>
            </div>

            {/* Divider */}
            <div className="h-px bg-slate-800/80" />

            {/* About Me / Bio */}
            <div className="space-y-1.5">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                Tiểu sử (About Me)
              </div>
              <p className="text-xs text-slate-300 leading-relaxed font-normal bg-slate-900/60 p-3 rounded-lg border border-slate-850">
                {settings.bio || 'Chưa thiết lập tiểu sử cá nhân.'}
              </p>
            </div>

            {/* Activity Status */}
            <div className="pt-1">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                Hoạt động hiện tại (Activity)
              </div>
              <div className="flex items-center gap-3 p-2.5 rounded-lg bg-slate-900/90 border border-slate-800 text-xs">
                <div className="p-2 rounded-md bg-purple-500/10 text-purple-400">
                  <Cpu className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <div className="font-semibold text-white truncate">Đang tối ưu hóa Relay Node #04</div>
                  <div className="text-[11px] text-slate-400 font-mono truncate">VS Code · 2 giờ 45 phút</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. THEME PRESETS SELECTOR */}
      <div className="space-y-3">
        <div>
          <h3 className="text-sm font-semibold text-slate-200">Bảng màu chủ đạo (Theme Presets)</h3>
          <p className="text-xs text-slate-400">Chọn phong cách thị giác ảnh hưởng đến đường nét thẻ, banner và thanh công cụ.</p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {THEME_PRESETS.map((preset) => {
            const isSelected = settings.activeTheme === preset.id;
            return (
              <button
                key={preset.id}
                type="button"
                onClick={() => {
                  updateSetting('activeTheme', preset.id);
                  triggerToast(`Đã áp dụng chủ đề ${preset.name}`);
                }}
                className={`flex items-center gap-3 p-3 rounded-xl border text-left transition-all ${
                  isSelected
                    ? 'bg-slate-900 border-purple-500/80 shadow-[0_0_15px_rgba(168,85,247,0.15)] ring-1 ring-purple-500/40'
                    : 'bg-slate-950/40 border-slate-800 hover:bg-slate-900/70 hover:border-slate-700'
                }`}
              >
                <div
                  className="w-7 h-7 rounded-lg shrink-0 flex items-center justify-center shadow-inner"
                  style={{ backgroundColor: preset.primary }}
                >
                  {isSelected && <Check className="w-4 h-4 text-slate-950 stroke-[3]" />}
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-slate-200 truncate">{preset.name}</div>
                  <div className="text-[10px] text-slate-400 font-mono">{preset.primary}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. AVATAR & BANNER CONTROLS */}
      <div className="bg-slate-950/60 rounded-xl border border-slate-800 p-5 space-y-4">
        <h3 className="text-sm font-semibold text-slate-200">Tuỳ chỉnh Avatar & Ảnh bìa</h3>

        <div className="space-y-4">
          {/* Avatar Choice */}
          <div>
            <label className="text-xs font-medium text-slate-300 block mb-2">Chọn ảnh đại diện Avatar</label>
            <div className="flex items-center gap-3 flex-wrap">
              {AVATAR_OPTIONS.map((av) => (
                <button
                  key={av.id}
                  type="button"
                  onClick={() => updateSetting('avatarUrl', av.url)}
                  className={`flex items-center gap-2 p-1.5 pr-3 rounded-full border transition-all ${
                    settings.avatarUrl === av.url
                      ? 'bg-purple-950/40 border-purple-500 ring-1 ring-purple-500/30 text-white'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <img
                    src={av.url}
                    alt={av.label}
                    className="w-7 h-7 rounded-full object-cover bg-slate-800"
                  />
                  <span className="text-xs font-medium">{av.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Banner Choice */}
          <div>
            <label className="text-xs font-medium text-slate-300 block mb-2">Chọn ảnh bìa Cover Banner</label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {BANNER_PRESETS.map((banner, idx) => (
                <button
                  key={banner.id}
                  type="button"
                  onClick={() => {
                    setActiveBannerIdx(idx);
                    updateSetting('bannerUrl', banner.url);
                  }}
                  className={`p-2.5 rounded-lg border text-left transition-all ${
                    activeBannerIdx === idx
                      ? 'bg-purple-950/30 border-purple-500/70 text-white'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-900'
                  }`}
                >
                  <div className="text-xs font-semibold text-slate-200">{banner.name}</div>
                  <div className="text-[10px] text-slate-500 mt-0.5">Preset #{idx + 1}</div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 4. BIO & ROLE EDITOR */}
      <div className="bg-slate-950/60 rounded-xl border border-slate-800 p-5 space-y-4">
        <div>
          <div className="flex items-center justify-between">
            <label className="text-sm font-semibold text-slate-200 block">Tiểu sử cá nhân (About Me)</label>
            <span
              className={`text-xs font-mono tabular-nums ${
                settings.bio.length > bioCharLimit ? 'text-rose-400' : 'text-slate-500'
              }`}
            >
              {settings.bio.length} / {bioCharLimit}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Giới thiệu ngắn về vai trò của bạn, các dự án mã nguồn mở hoặc múi giờ hoạt động.
          </p>
        </div>

        <textarea
          rows={3}
          value={settings.bio}
          onChange={(e) => {
            if (e.target.value.length <= bioCharLimit) {
              updateSetting('bio', e.target.value);
            }
          }}
          placeholder="Viết một đoạn giới thiệu ngắn..."
          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700/80 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500/50 transition-colors resize-none"
        />

        <div>
          <label className="text-xs font-semibold text-slate-300 block mb-1">Chức danh / Nhãn Role</label>
          <input
            type="text"
            value={settings.roleTag}
            onChange={(e) => updateSetting('roleTag', e.target.value)}
            placeholder="Ví dụ: Senior Systems Architect / Core Node"
            className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700/80 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 transition-colors"
          />
        </div>
      </div>

      {/* 5. BADGE CUSTOMIZATION */}
      <div className="bg-slate-950/60 rounded-xl border border-slate-800 p-5 space-y-4">
        <div>
          <h3 className="text-sm font-semibold text-slate-200">Huy hiệu danh dự (Badges)</h3>
          <p className="text-xs text-slate-400">Chọn các huy hiệu bạn muốn ghim trên thẻ thông tin cá nhân của mình.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {AVAILABLE_BADGES.map((badge) => {
            const isChecked = settings.badges.includes(badge.id);
            return (
              <div
                key={badge.id}
                onClick={() => toggleBadge(badge.id)}
                className={`p-3 rounded-lg border flex items-center justify-between cursor-pointer transition-all ${
                  isChecked
                    ? 'bg-purple-950/20 border-purple-500/50 text-slate-200'
                    : 'bg-slate-900/40 border-slate-800/80 text-slate-400 hover:bg-slate-900'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-md bg-slate-800">{getBadgeIcon(badge.icon)}</div>
                  <div>
                    <div className="text-xs font-semibold text-white">{badge.name}</div>
                    <div className="text-[10px] text-slate-400">{badge.description}</div>
                  </div>
                </div>

                <div
                  className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 ${
                    isChecked
                      ? 'bg-purple-600 border-purple-500 text-white'
                      : 'border-slate-700 bg-slate-800'
                  }`}
                >
                  {isChecked && <Check className="w-3 h-3 stroke-[3]" />}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
