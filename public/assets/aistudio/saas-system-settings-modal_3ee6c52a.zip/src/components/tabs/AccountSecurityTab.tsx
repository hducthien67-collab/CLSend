import React, { useState, useRef, useEffect } from 'react';
import {
  ShieldCheck,
  User,
  AtSign,
  KeyRound,
  Eye,
  EyeOff,
  Mail,
  CheckCircle2,
  AlertCircle,
  Laptop,
  Smartphone,
  Tv,
  Monitor,
  LogOut,
  RefreshCw,
  Clock,
  MapPin,
  Lock,
} from 'lucide-react';
import { DeviceSession, HardwareType, SystemSettingsState } from '../../types/settings';

interface Props {
  settings: SystemSettingsState;
  updateSetting: <K extends keyof SystemSettingsState>(key: K, value: SystemSettingsState[K]) => void;
  triggerToast: (msg: string) => void;
}

const INITIAL_SESSIONS: DeviceSession[] = [
  {
    id: 'sess_1',
    name: 'MacBook Pro 16" (Node Tokyo)',
    type: 'laptop',
    browser: 'Chrome 128 · macOS Sonoma',
    ip: '118.69.182.10',
    location: 'Tokyo, Nhật Bản',
    lastActive: 'Đang hoạt động (Hiện tại)',
    isCurrent: true,
  },
  {
    id: 'sess_2',
    name: 'iPhone 16 Pro Max',
    type: 'phone',
    browser: 'SaaS Native Client · iOS 18',
    ip: '14.232.208.45',
    location: 'Hà Nội, Việt Nam',
    lastActive: '12 phút trước',
    isCurrent: false,
  },
  {
    id: 'sess_3',
    name: 'Windows Studio Workstation',
    type: 'pc',
    browser: 'Edge 128 · Windows 11 Pro',
    ip: '103.77.241.19',
    location: 'Singapore Gateway',
    lastActive: '2 ngày trước',
    isCurrent: false,
  },
  {
    id: 'sess_4',
    name: 'Smart TV Lounge Node',
    type: 'tv',
    browser: 'Tizen OS 7.0 · Room #4',
    ip: '192.168.1.180',
    location: 'Mạng LAN Nội Bộ',
    lastActive: '5 ngày trước',
    isCurrent: false,
  },
];

export const AccountSecurityTab: React.FC<Props> = ({ settings, updateSetting, triggerToast }) => {
  // Password state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);

  // OTP state
  const [otpDigits, setOtpDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [otpCountdown, setOtpCountdown] = useState<number>(0);
  const [isVerifyingOtp, setIsVerifyingOtp] = useState<boolean>(false);
  const [isEmailVerified, setIsEmailVerified] = useState<boolean>(settings.emailVerified);
  const otpInputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Sessions state
  const [sessions, setSessions] = useState<DeviceSession[]>(INITIAL_SESSIONS);

  // Password strength calculation
  const getPasswordStrength = (pwd: string) => {
    if (!pwd) return { score: 0, text: 'Chưa nhập', color: 'bg-slate-700' };
    let score = 0;
    if (pwd.length >= 8) score += 1;
    if (/[A-Z]/.test(pwd) && /[a-z]/.test(pwd)) score += 1;
    if (/[0-9]/.test(pwd)) score += 1;
    if (/[^A-Za-z0-9]/.test(pwd)) score += 1;

    if (score <= 1) return { score: 1, text: 'Yếu', color: 'bg-rose-500' };
    if (score === 2) return { score: 2, text: 'Trung bình', color: 'bg-amber-500' };
    if (score === 3) return { score: 3, text: 'Tốt', color: 'bg-teal-500' };
    return { score: 4, text: 'Rất mạnh', color: 'bg-emerald-500' };
  };

  const pwdStrength = getPasswordStrength(newPassword);

  const handleUpdatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPassword) {
      triggerToast('Vui lòng nhập mật khẩu hiện tại');
      return;
    }
    if (newPassword.length < 8) {
      triggerToast('Mật khẩu mới phải có tối thiểu 8 ký tự');
      return;
    }
    if (newPassword !== confirmPassword) {
      triggerToast('Mật khẩu xác nhận không trùng khớp');
      return;
    }
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    triggerToast('Mật khẩu đã được cập nhật thành công');
  };

  // OTP Countdown timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (otpCountdown > 0) {
      timer = setTimeout(() => setOtpCountdown((c) => c - 1), 1000);
    }
    return () => clearTimeout(timer);
  }, [otpCountdown]);

  const handleSendOtp = () => {
    setOtpCountdown(60);
    // Simulate sending OTP 739284
    setOtpDigits(['7', '3', '', '', '', '']);
    triggerToast('Mã OTP 6 số đã được gửi tới email của bạn (mẫu: 739284)');
    if (otpInputRefs.current[2]) {
      otpInputRefs.current[2]?.focus();
    }
  };

  const handleOtpChange = (index: number, val: string) => {
    if (!/^\d*$/.test(val)) return;

    const newOtp = [...otpDigits];
    newOtp[index] = val.slice(-1);
    setOtpDigits(newOtp);

    // Auto advance focus
    if (val && index < 5) {
      otpInputRefs.current[index + 1]?.focus();
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otpDigits[index] && index > 0) {
      otpInputRefs.current[index - 1]?.focus();
    }
  };

  const handleOtpPaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    if (!pasted) return;
    const newOtp = [...otpDigits];
    for (let i = 0; i < 6; i++) {
      newOtp[i] = pasted[i] || '';
    }
    setOtpDigits(newOtp);
    const lastFilled = Math.min(pasted.length, 5);
    otpInputRefs.current[lastFilled]?.focus();
  };

  const handleVerifyOtp = () => {
    const fullCode = otpDigits.join('');
    if (fullCode.length !== 6) {
      triggerToast('Vui lòng nhập đầy đủ 6 số OTP');
      return;
    }
    setIsVerifyingOtp(true);
    setTimeout(() => {
      setIsVerifyingOtp(false);
      setIsEmailVerified(true);
      updateSetting('emailVerified', true);
      triggerToast('Xác thực bảo mật email thành công!');
    }, 750);
  };

  const handleTerminateSession = (sessionId: string) => {
    setSessions((prev) => prev.filter((s) => s.id !== sessionId));
    triggerToast('Đã thu hồi phiên đăng nhập trên thiết bị');
  };

  const handleTerminateAllOtherSessions = () => {
    setSessions((prev) => prev.filter((s) => s.isCurrent));
    triggerToast('Đã đăng xuất khỏi tất cả các thiết bị khác thành công');
  };

  const getHardwareIcon = (type: HardwareType) => {
    switch (type) {
      case 'laptop':
        return <Laptop className="w-4 h-4 text-teal-400" />;
      case 'phone':
        return <Smartphone className="w-4 h-4 text-cyan-400" />;
      case 'pc':
        return <Monitor className="w-4 h-4 text-emerald-400" />;
      case 'tv':
        return <Tv className="w-4 h-4 text-amber-400" />;
    }
  };

  return (
    <div className="space-y-8 max-w-3xl">
      {/* Section Header */}
      <div className="border-b border-slate-800 pb-5">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-teal-400">
          <span className="w-2 h-2 rounded-full bg-teal-500"></span>
          Tài khoản & An toàn bảo mật
        </div>
        <h2 className="text-xl font-bold text-white mt-1">Account & Security Center</h2>
        <p className="text-sm text-slate-400 mt-1">
          Quản lý định danh tài khoản, kiểm soát mật khẩu cấp cao, xác minh 6 số OTP và phiên đăng nhập thiết bị.
        </p>
      </div>

      {/* 1. USERNAME & DISPLAY NAME */}
      <div className="bg-slate-950/60 rounded-xl border border-slate-800 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-200">Định danh tài khoản người dùng</h3>
          <span className="text-[11px] font-mono text-teal-400 bg-teal-950/50 px-2 py-0.5 rounded border border-teal-800/40">
            Tài khoản đã xác thực
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Display Name */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-slate-400" />
              Tên hiển thị (Display Name)
            </label>
            <input
              type="text"
              value={settings.displayName}
              onChange={(e) => updateSetting('displayName', e.target.value)}
              placeholder="Alex Rivera"
              className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700/80 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500/50 transition-colors"
            />
            <p className="text-[11px] text-slate-500">Tên này sẽ hiển thị công khai trên tất cả các kênh thông tin.</p>
          </div>

          {/* Username */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <AtSign className="w-3.5 h-3.5 text-slate-400" />
              Tên đăng nhập (Username)
            </label>
            <div className="relative">
              <input
                type="text"
                value={settings.username}
                onChange={(e) => {
                  let val = e.target.value;
                  if (!val.startsWith('@')) val = '@' + val.replace(/^@+/, '');
                  updateSetting('username', val);
                }}
                placeholder="@alex.dev"
                className="w-full pl-3.5 pr-20 py-2.5 bg-slate-900 border border-slate-700/80 rounded-lg text-sm text-white font-mono placeholder-slate-500 focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500/50 transition-colors"
              />
              <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] font-semibold text-teal-400 bg-teal-950/80 px-2 py-0.5 rounded border border-teal-800/40">
                Khả dụng
              </span>
            </div>
            <p className="text-[11px] text-slate-500">Sử dụng cho liên kết trực tiếp và gọi tên trong hệ thống.</p>
          </div>
        </div>
      </div>

      {/* 2. CHANGE PASSWORD */}
      <form onSubmit={handleUpdatePassword} className="bg-slate-950/60 rounded-xl border border-slate-800 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <KeyRound className="w-4 h-4 text-teal-400" />
            <h3 className="text-sm font-semibold text-slate-200">Đổi mật khẩu tài khoản</h3>
          </div>
          <span className="text-[11px] text-slate-400">Đổi lần cuối: 28 ngày trước</span>
        </div>

        <div className="space-y-3">
          {/* Current Password */}
          <div>
            <label className="text-xs font-medium text-slate-300 block mb-1">Mật khẩu hiện tại</label>
            <div className="relative">
              <input
                type={showCurrentPassword ? 'text' : 'password'}
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="Nhập mật khẩu hiện tại..."
                className="w-full pl-3.5 pr-10 py-2 bg-slate-900 border border-slate-700/80 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-teal-500 transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
              >
                {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* New Password & Confirm */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">Mật khẩu mới</label>
              <div className="relative">
                <input
                  type={showNewPassword ? 'text' : 'password'}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Tối thiểu 8 ký tự..."
                  className="w-full pl-3.5 pr-10 py-2 bg-slate-900 border border-slate-700/80 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-teal-500 transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowNewPassword(!showNewPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
                >
                  {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">Xác nhận mật khẩu mới</label>
              <input
                type={showNewPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Nhập lại mật khẩu mới..."
                className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700/80 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-teal-500 transition-colors"
              />
            </div>
          </div>

          {/* Strength Bar */}
          {newPassword && (
            <div className="space-y-1.5 pt-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Độ phức tạp mật khẩu:</span>
                <span className="font-semibold text-white">{pwdStrength.text}</span>
              </div>
              <div className="grid grid-cols-4 gap-1.5 h-1.5">
                {[1, 2, 3, 4].map((step) => (
                  <div
                    key={step}
                    className={`rounded-full transition-all duration-300 ${
                      pwdStrength.score >= step ? pwdStrength.color : 'bg-slate-800'
                    }`}
                  />
                ))}
              </div>
            </div>
          )}

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={!currentPassword || !newPassword}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 transition-colors"
            >
              Cập nhật mật khẩu
            </button>
          </div>
        </div>
      </form>

      {/* 3. EMAIL SECURITY & 6-DIGIT OTP VERIFICATION */}
      <div className="bg-slate-950/60 rounded-xl border border-slate-800 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2.5">
            <Mail className="w-4 h-4 text-teal-400" />
            <div>
              <h3 className="text-sm font-semibold text-white">Xác thực Email bảo mật qua mã OTP</h3>
              <p className="text-xs text-slate-400">{settings.email}</p>
            </div>
          </div>
          {isEmailVerified ? (
            <span className="inline-flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-950/50 border border-emerald-800/40 px-2.5 py-1 rounded-md font-medium self-start sm:self-auto">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Đã xác thực cấp 2
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5 text-xs text-amber-400 bg-amber-950/50 border border-amber-800/40 px-2.5 py-1 rounded-md font-medium self-start sm:self-auto">
              <AlertCircle className="w-3.5 h-3.5" />
              Chưa xác minh mã OTP
            </span>
          )}
        </div>

        {/* 6-box OTP interactive layout */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-medium text-slate-300">
              Nhập mã xác thực 6 số (One-Time Password)
            </label>
            <button
              type="button"
              disabled={otpCountdown > 0}
              onClick={handleSendOtp}
              className="text-xs text-teal-400 hover:text-teal-300 disabled:text-slate-600 font-medium flex items-center gap-1 transition-colors"
            >
              <RefreshCw className="w-3 h-3" />
              {otpCountdown > 0 ? `Gửi lại sau (${otpCountdown}s)` : 'Gửi mã xác thực OTP'}
            </button>
          </div>

          {/* 6 Digit Inputs */}
          <div className="flex items-center justify-center gap-2 sm:gap-3 py-2" onPaste={handleOtpPaste}>
            {otpDigits.map((digit, idx) => (
              <input
                key={idx}
                ref={(el) => {
                  otpInputRefs.current[idx] = el;
                }}
                type="text"
                inputMode="numeric"
                maxLength={1}
                value={digit}
                onChange={(e) => handleOtpChange(idx, e.target.value)}
                onKeyDown={(e) => handleOtpKeyDown(idx, e)}
                className="w-11 h-13 sm:w-12 sm:h-14 bg-slate-900 border border-slate-700 text-center text-lg sm:text-xl font-mono font-bold text-teal-300 rounded-lg focus:outline-none focus:border-teal-500 focus:ring-2 focus:ring-teal-500/30 transition-all shadow-inner"
              />
            ))}
          </div>

          <div className="flex items-center justify-between pt-1">
            <span className="text-[11px] text-slate-500">
              Mẹo: Bạn có thể dán (paste) trực tiếp 6 chữ số vào ô đầu tiên.
            </span>
            <button
              type="button"
              onClick={handleVerifyOtp}
              disabled={isVerifyingOtp || otpDigits.join('').length < 6}
              className="px-4 py-2 bg-teal-600 hover:bg-teal-500 disabled:opacity-40 text-slate-950 font-semibold text-xs rounded-lg transition-colors flex items-center gap-1.5"
            >
              {isVerifyingOtp ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <ShieldCheck className="w-3.5 h-3.5" />}
              <span>{isVerifyingOtp ? 'Đang kiểm tra...' : 'Xác thực ngay'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 4. ACTIVE SESSIONS LIST */}
      <div className="bg-slate-950/60 rounded-xl border border-slate-800 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-200">Phiên đăng nhập trên các thiết bị</h3>
            <p className="text-xs text-slate-400">Danh sách thiết bị hiện đang duy trì token xác thực với tài khoản của bạn.</p>
          </div>

          {sessions.length > 1 && (
            <button
              type="button"
              onClick={handleTerminateAllOtherSessions}
              className="text-xs text-rose-400 hover:text-rose-300 font-medium px-3 py-1.5 rounded-lg border border-rose-900/50 bg-rose-950/30 hover:bg-rose-950/60 transition-colors self-start sm:self-auto shrink-0"
            >
              Đăng xuất khỏi tất cả các thiết bị khác
            </button>
          )}
        </div>

        <div className="space-y-2.5">
          {sessions.map((sess) => (
            <div
              key={sess.id}
              className={`p-3.5 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                sess.isCurrent
                  ? 'bg-teal-950/15 border-teal-500/40'
                  : 'bg-slate-900/50 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start gap-3">
                <div
                  className={`p-2.5 rounded-lg shrink-0 ${
                    sess.isCurrent ? 'bg-teal-500/20 text-teal-400' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {getHardwareIcon(sess.type)}
                </div>
                <div className="space-y-0.5 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-semibold text-white">{sess.name}</span>
                    {sess.isCurrent && (
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30">
                        Thiết bị này
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-slate-400">{sess.browser}</div>
                  <div className="flex items-center gap-3 text-[10px] text-slate-500 pt-0.5 font-mono">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-slate-500" />
                      {sess.location}
                    </span>
                    <span>·</span>
                    <span>IP: {sess.ip}</span>
                    <span>·</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-500" />
                      {sess.lastActive}
                    </span>
                  </div>
                </div>
              </div>

              {!sess.isCurrent && (
                <button
                  type="button"
                  onClick={() => handleTerminateSession(sess.id)}
                  title="Đăng xuất phiên này"
                  className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 border border-slate-800 hover:border-rose-900/50 transition-colors flex items-center gap-1.5 self-end sm:self-auto shrink-0"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Đăng xuất</span>
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
