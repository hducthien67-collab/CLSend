import React, { useState, useEffect } from 'react';
import {
  Settings,
  Cpu,
  Palette,
  ShieldCheck,
  Radio,
  Server,
  Zap,
  Globe2,
  Sliders,
  Laptop,
  CheckCircle2,
  ExternalLink,
  ChevronRight,
  Terminal,
  Activity,
  User,
} from 'lucide-react';
import { SettingsModal } from './components/SettingsModal';
import { TabType } from './types/settings';

export default function App() {
  const [isModalOpen, setIsModalOpen] = useState(true);
  const [targetTab, setTargetTab] = useState<TabType>('devices');

  const openSettings = (tab: TabType = 'devices') => {
    setTargetTab(tab);
    setIsModalOpen(true);
  };

  // Keyboard shortcut: Cmd+, or Ctrl+, to open settings
  useEffect(() => {
    const handleShortcut = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === ',') {
        e.preventDefault();
        setIsModalOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleShortcut);
    return () => window.removeEventListener('keydown', handleShortcut);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950">
      {/* SaaS Navigation Header */}
      <header className="border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-md sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-emerald-500/20">
              <Radio className="w-5 h-5 stroke-[2.5]" />
            </div>
            <span className="text-base font-bold tracking-tight text-white whitespace-nowrap">
              Nexus Relay SaaS
            </span>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-400">
            <a href="#nodes" className="hover:text-slate-200 transition-colors whitespace-nowrap">
              Relay Mesh
            </a>
            <a href="#devices" className="hover:text-slate-200 transition-colors whitespace-nowrap">
              Thiết bị kết nối
            </a>
            <a href="#metrics" className="hover:text-slate-200 transition-colors whitespace-nowrap">
              Chỉ số đường truyền
            </a>
            <a href="#security" className="hover:text-slate-200 transition-colors whitespace-nowrap">
              Bảo mật OTP
            </a>
          </nav>

          {/* Zone 3: Primary Action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => openSettings('devices')}
              className="flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 shadow-md shadow-emerald-500/20 transition-all cursor-pointer whitespace-nowrap"
            >
              <Settings className="w-4 h-4" />
              <span>Cài đặt hệ thống</span>
              <kbd className="hidden sm:inline-block ml-1 px-1.5 py-0.5 rounded bg-emerald-600/30 text-[10px] font-mono text-slate-950">
                ⌘ ,
              </kbd>
            </button>
          </div>
        </div>
      </header>

      {/* Main SaaS Workspace Background */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-8 space-y-8">
        {/* Hero Section */}
        <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 shadow-xl relative overflow-hidden">
          <div className="relative z-10 max-w-2xl space-y-3">
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-md bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              Cụm mạng Relay Tokyo Node #01 Trực tuyến 24/7
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Cửa sổ Cài đặt hệ thống chuẩn SaaS Cao cấp
            </h1>
            <p className="text-sm text-slate-400 leading-relaxed">
              Thiết kế theo ngôn ngữ Linear, Vercel & Discord với 3 danh mục chính: Thiết bị & Mạng, Tuỳ biến Hồ sơ giao diện, và Quản trị Bảo mật OTP hai lớp.
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                onClick={() => openSettings('devices')}
                className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center gap-2 transition-colors"
              >
                <Cpu className="w-4 h-4 text-emerald-400" />
                <span>Mở Devices & Network</span>
              </button>
              <button
                onClick={() => openSettings('profile')}
                className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center gap-2 transition-colors"
              >
                <Palette className="w-4 h-4 text-purple-400" />
                <span>Mở Profile & Theme</span>
              </button>
              <button
                onClick={() => openSettings('security')}
                className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center gap-2 transition-colors"
              >
                <ShieldCheck className="w-4 h-4 text-teal-400" />
                <span>Mở Account & Security</span>
              </button>
            </div>
          </div>
        </div>

        {/* 3 Interactive Cards representing the 3 Tabs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Devices & Network */}
          <div
            onClick={() => openSettings('devices')}
            className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-emerald-500/50 hover:bg-slate-900 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <Cpu className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white group-hover:text-emerald-400 transition-colors">
                  Devices & Network
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Thiết lập tên hiển thị, 4 loại phần cứng (Laptop, PC, Điện thoại, Smart TV), kiểm tra Ping máy chủ Relay 24/7, tự động bật Auto-Accept và chuông thông báo.
                </p>
              </div>
            </div>

            <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-emerald-400 font-semibold">
              <span>Cấu hình thiết bị</span>
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 2: Profile & Theme */}
          <div
            onClick={() => openSettings('profile')}
            className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-purple-500/50 hover:bg-slate-900 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-lg bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center">
                <Palette className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white group-hover:text-purple-400 transition-colors">
                  Profile & Theme
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Xem trước thẻ hồ sơ phong cách Discord (Avatar, Cover Banner, Badges, Bio), tuỳ chỉnh 6 bảng màu chủ đạo (Vercel, Linear, Amethyst, v.v.).
                </p>
              </div>
            </div>

            <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-purple-400 font-semibold">
              <span>Tuỳ chỉnh giao diện</span>
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 3: Account & Security */}
          <div
            onClick={() => openSettings('security')}
            className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-teal-500/50 hover:bg-slate-900 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-lg bg-teal-500/10 border border-teal-500/20 text-teal-400 flex items-center justify-center">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white group-hover:text-teal-400 transition-colors">
                  Account & Security
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Quản lý @username, display name, đổi mật khẩu kèm thanh đo độ mạnh, xác thực email bảo mật qua ô nhập mã OTP 6 số và quản lý phiên thiết bị.
                </p>
              </div>
            </div>

            <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between text-xs text-teal-400 font-semibold">
              <span>Bảo mật tài khoản</span>
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>

        {/* Live Network & Node Status preview table */}
        <div className="p-5 rounded-xl bg-slate-900/40 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-bold text-white">Trạng thái hạ tầng Relay & Nút mạng cục bộ</h3>
            </div>
            <span className="text-xs text-slate-400 font-mono">Mesh Protocol v2.4</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
            <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800/60">
              <div className="text-slate-500">Uptime Relay</div>
              <div className="text-white font-bold text-sm mt-1 tabular-nums">99.98%</div>
            </div>
            <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800/60">
              <div className="text-slate-500">Độ trễ trung bình</div>
              <div className="text-emerald-400 font-bold text-sm mt-1 tabular-nums">24 ms</div>
            </div>
            <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800/60">
              <div className="text-slate-500">Phiên hoạt động</div>
              <div className="text-white font-bold text-sm mt-1 tabular-nums">4 thiết bị</div>
            </div>
            <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800/60">
              <div className="text-slate-500">Bảo mật cấp 2</div>
              <div className="text-teal-400 font-bold text-sm mt-1">Đã kích hoạt OTP</div>
            </div>
          </div>
        </div>
      </main>

      {/* The Central Settings Modal Component */}
      <SettingsModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        initialTab={targetTab}
      />
    </div>
  );
}
