export type TabType = 'devices' | 'profile' | 'security';

export type HardwareType = 'laptop' | 'pc' | 'phone' | 'tv';

export type ThemePresetId = 'amethyst' | 'emerald' | 'teal' | 'slate' | 'monochrome' | 'oceanic';

export interface ThemePreset {
  id: ThemePresetId;
  name: string;
  primary: string; // Tailwind color class or hex
  accent: string;
  previewGradient: string;
  borderClass: string;
}

export interface BadgeItem {
  id: string;
  name: string;
  icon: string;
  description: string;
  active: boolean;
}

export interface DeviceSession {
  id: string;
  name: string;
  type: HardwareType;
  browser: string;
  ip: string;
  location: string;
  lastActive: string;
  isCurrent: boolean;
}

export interface RelayServer {
  id: string;
  name: string;
  region: string;
  flag: string;
  ping: number;
  status: 'online' | 'degraded' | 'offline';
}

export interface SystemSettingsState {
  // Tab 1: Devices & Network
  deviceName: string;
  hardwareType: HardwareType;
  relayAutoFailover: boolean;
  selectedRelayServer: string;
  autoAccept: boolean;
  soundEnabled: boolean;
  soundVolume: number;
  transferBandwidthLimit: string;

  // Tab 2: Profile & Theme
  displayName: string;
  username: string;
  bio: string;
  roleTag: string;
  avatarUrl: string;
  bannerUrl: string;
  activeTheme: ThemePresetId;
  badges: string[]; // list of active badge IDs

  // Tab 3: Account & Security
  email: string;
  emailVerified: boolean;
  twoFactorEnabled: boolean;
}
